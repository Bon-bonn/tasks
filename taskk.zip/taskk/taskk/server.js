const express = require ("express");
const {ConnectToDb, getDb} = require("./bd");
const PORT = 3000;
const app = express ();
let db;

connectToDb((err)=> {
    
    if (!err) {
        app.listen (PORT, (err) => {
            err ? console.log(err) : console.log (`listening port ${PORT}`);
})

db.getDb();
    } else {
        console.log (`Db connection error: ${err}`);
    }
})

app.get("/test", (req, res) =>{
    let test = []

    db
        .collection("testCollection")
        .find()
        .forEach((testCollection) => test.push(testCollection))
        .then (() => {
            res
            .status(200)
            .json(test)
        })
})